package com.example.swatseal.androidlab1;

import android.app.Application;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.annotations.SerializedName;
import com.twitter.sdk.android.core.Callback;
import com.twitter.sdk.android.core.Result;
import com.twitter.sdk.android.core.Twitter;
import com.twitter.sdk.android.core.TwitterAuthToken;
import com.twitter.sdk.android.core.TwitterCore;
import com.twitter.sdk.android.core.TwitterException;
import com.twitter.sdk.android.core.TwitterSession;
import com.twitter.sdk.android.core.identity.TwitterLoginButton;
import android.view.View;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity{

    Toolbar toolbar;
    TwitterLoginButton loginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Twitter.initialize(this);
        setContentView(R.layout.activity_main);

        loginButton = (TwitterLoginButton) findViewById(R.id.login_button);
        loginButton.setCallback(new Callback<TwitterSession>() {
            @Override
            public void success(Result<TwitterSession> result) {
                // Do something with result, which provides a TwitterSession for making API calls
                TwitterSession session = TwitterCore.getInstance().getSessionManager().getActiveSession();
                TwitterAuthToken authToken = session.getAuthToken();
                String token = authToken.token;
                String secret = authToken.secret;

                login(session);
            }

            @Override
            public void failure(TwitterException exception) {
                // Do something on failure
            }
        });
    }

    public void login(TwitterSession session)
    {
        String username = session.getUserName();
        Intent intent = new Intent(MainActivity.this, Homepage.class);
        intent.putExtra("username", username);
        startActivity(intent);
    }

    protected void onSignUpClick(View v)
    {
        if(v.getId() == R.id.button2)
        {
            Intent i = new Intent(MainActivity.this, SignUp.class);
            startActivity(i);
        }
    }

    protected void onSignInClick(View v)
    {

        if(v.getId() == R.id.button)
        {
            ArrayList<String> UserList = new ArrayList<String>();
            ArrayList<String> PasswordList = new ArrayList<String>();

            Bundle bundle = getIntent().getExtras();
            if(bundle != null){
                UserList = (ArrayList<String>)bundle.getStringArrayList("UserList");
                PasswordList = (ArrayList<String>)bundle.getStringArrayList("PasswordList");
            }
            EditText enteredEmailView = (EditText) findViewById(R.id.editText);
            String enteredEmail = enteredEmailView.getText().toString();

            EditText enteredPasswordView = (EditText) findViewById(R.id.editText2);
            String enteredPassword = enteredPasswordView.getText().toString();

            enteredPassword = enteredPassword.replaceAll("\\s+", "");

            String userEmail = "";
            String userPassword = "";
            boolean searchForPassword = false;

            //get password by finding name index
            if(!(UserList.isEmpty())) {
                for (int i = 0; i <= UserList.size(); i++) {
                    //bug with .get()
                    if (enteredEmail.equals(UserList.get(i).toString())) {
                        userEmail = UserList.get(i).toString();
                        userPassword = PasswordList.get(i).toString();
                        searchForPassword = true;
                    }

                }
            }

            if(searchForPassword && (enteredPassword.equals(userPassword)))
            {
                Intent i = new Intent(MainActivity.this, Homepage.class);
                startActivity(i);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Pass the activity result to the login button.
        loginButton.onActivityResult(requestCode, resultCode, data);
    }
}
