package com.example.swatseal.androidlab1;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class SignUp extends Activity{

    ArrayList<String> UserList = new ArrayList<>();
    ArrayList<String> PasswordList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);


        UserList.add("username");
        PasswordList.add("password");

        TextView UserPass = (TextView) findViewById(R.id.textView4);
        UserPass.setText(UserList.get(0));

        Intent in = new Intent(this, MainActivity.class);
        in.putExtra("UserList", UserList);
        in.putExtra("PasswordList", PasswordList);
        startActivity(in);

    }

    public void submitSignup(View v){
        if(v.getId() == R.id.button4)
        {
            EditText newEmailView = (EditText) findViewById(R.id.editText3);
            String newEmail = newEmailView.getText().toString();

            EditText newPasswordView = (EditText) findViewById(R.id.editText4);
            String newPassword = newPasswordView.getText().toString();

            EditText newConfirmPassView = (EditText) findViewById(R.id.editText5);
            String newConfirmPass= newConfirmPassView.getText().toString();

            newPassword = newPassword.replaceAll("\\s+", "");
            newConfirmPass = newPassword.replaceAll("\\s+","");



            if(newPassword == newConfirmPass)
            {
                UserList.add(newEmail);
                PasswordList.add(newPassword);

                Intent in = new Intent(this, MainActivity.class);
                in.putExtra("UserList", UserList);
                in.putExtra("PasswordList", PasswordList);
                startActivity(in);
            }

        }
    }
}
