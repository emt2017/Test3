package com.example.swatseal.androidlab1;

import com.google.gson.annotations.SerializedName;

public class newUser {

    private String usernameStr;

    private String passwordStr;

    public newUser(String username, String password){
        usernameStr = username;
        passwordStr = password;
    }

    public String getName(){
        return usernameStr;
    }

    public String getPassword(){
        return passwordStr;
    }
}
